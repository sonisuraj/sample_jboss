require('./angular-cookies');
module.exports = 'ngCookies';
